/* eslint-disable no-unused-vars */
import { Server } from "http";
import mongoose from "mongoose";
import app from "./app";
import config from "./app/config";

// server type
// eslint-disable-next-line @typescript-eslint/no-unused-vars
let server: Server;
async function main() {
  try {
    await mongoose.connect(config.database_url as string);
    // use `await mongoose.connect('mongodb://user:password@127.0.0.1:27017/test');` if your database has auth enabled

    //server
    server = app.listen(config.port, () => {
      console.log(`Example My app listening on port ${config.port}`);
    });
  } catch (err) {
    console.log(err);
  }
}

main();

// unhandle Rejection --> unhandaled error gula catch korar por server close korar jonno
// for Asyncrhonus:
process.on("unhandledRejection", err => {
  console.log(`😈 unhandledRejection is detected, Shutting Down the Server`);
  // if (server) {
  //at first of the server then -> process close/exit
  //   server.close(() => {
  //     process.exit(1);
  //   });
  // }
  // process.exit(1);
  console.error("Unhandled Rejection detected,", err);
});

// for Synchrouns:
process.on("uncaughtException", err => {
  console.log(
    `😈 uncaughtException is detected, Shutting Down the Server`,
    err,
  );
  // process.exit(1);
});
